# routing
Rails.application.routes.draw do
  resources :across_project_evm
end
